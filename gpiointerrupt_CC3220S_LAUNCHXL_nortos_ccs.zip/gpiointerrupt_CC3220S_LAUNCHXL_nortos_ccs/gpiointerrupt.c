/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


//  =================================
//  ======== gpiointerrupt.c ========
//  =================================
//  Problem Description:
//
//  This code interacts with the CC3220x LAUNCHXL hardware in order to
//  turn the red LED on the device on and off as specified in the
//  "5-1 Milestone Three" assignment specification for the SNHU course
//  CS-350, Emerging Systems Architectures & Technologies.
//
//  Solution
//
//  The solution is implemented in the form of a state machine. When the
//  program is ran, the hardware will begin using two LED lights to flash
//  "SOS" in morse code. In order to do this, the program first translates
//  the "SOS" string to morse code symbols, then transitions through various
//  states in order to turn lights on and off, add pauses for human readability,
//  and handle button presses. Dots are represented by a quick red flash, while
//  dashes are represented by a slightly longer green flash.
//
//  If left alone, the device will continuously flash "SOS". However, the user
//  can press the two buttons on the device to change the message from "SOS"
//  to "OK". After doing this, the user can press the buttons again to toggle
//  between "SOS" or "OK". If these buttons are pressed in the middle of a message,
//  the message will continue to flash until it is finished before beginning to
//  flash the other word.
//
//  The initial word can be changed if so desired. This program supports flashing
//  any alphabetical string in morse code. Simply search for word = "SOS"; in
//  the MESSAGE_INIT action state and change the word. If this is done, the new
//  word provided will be flashed on startup. However, buttons will have no effect
//  in this circumstance.

#include <stdint.h>
#include <stddef.h>
#include <stdlib.h> //  For malloc
#include <string.h> //  For stringcmp
#include <ctype.h>  //  For char functions

//  Driver Header files
#include <ti/drivers/GPIO.h>

//  Driver configuration
#include "ti_drivers_config.h"

//  Timer header files
#include <ti/drivers/Timer.h>

//  Macros to identify state of the machine
#define MESSAGE_INIT 0          //  Initialization state
#define MESSAGE_FLASH_DOT 1     //  State machine is flashing a dot
#define MESSAGE_FLASH_DASH 2    //  State machine is flashing a dash
#define MESSAGE_PAUSE_SYMBOL 3  //  State machine is pausing after flashing a symbol
#define MESSAGE_PAUSE_CHAR 4    //  State machine is pausing after flashing a character
#define MESSAGE_PAUSE_WORD 5    //  State machine is pausing after flashing a word

//  Macros to identify period length for states
#define INIT_PERIODS 1
#define FLASH_DOT_PERIODS 1
#define FLASH_DASH_PERIODS 3
#define MESSAGE_PAUSE_SYMBOL_PERIODS 1
#define MESSAGE_PAUSE_CHAR_PERIODS 3
#define MESSAGE_PAUSE_WORD_PERIODS 7

//  Macro to identify the maximum amount of symbols a letter in morse code may have
unsigned int MAX_SYMBOLS = 4;

//  Word to be flashed by the state machine
char* word;

//  Enum to contain the different symbols used in morse code
//  DOT     - Indicates a dot symbol
//  DASH    - Indicates a dash symbol
//  WAIT    - Indicates a natural pause after a symbol
//  END     - Indicates the end of a message
enum MORSE_CODE_SYMBOLS { DOT, DASH, WAIT, END};

//  Pointer to an array of symbols to be processed by the state machine
enum MORSE_CODE_SYMBOLS* sequence;

//  Variable referencing the next symbol to be flashed by the state machine
enum MORSE_CODE_SYMBOLS nextSymbol;

//  Current position within the sequence array
unsigned short sequencePos;

//  Value representing whether any buttons on device were pressed
unsigned short buttonPressed = 0;

//  One byte variable used to represent the machine's current state. This will
//  always be assigned one of the macro values above
unsigned char state;

//  Variable used to represent how many periods have passed since
//  entering a state within the state machine
unsigned short periodCount = 0;

//  Converts a letter to morse code symbols
//  c       - Letter to be converted, must be 'a' - 'z' or 'A' - 'Z'
//  count   - Value indicating the amount of morse code symboled returns
//
//  Returns a pointer to an array of morse code symbols. If character
//  cannot be converted to morse code, it returns the END morse code
//  symbol, and count will be set to 0
//
//  This return value must be freed manually
enum MORSE_CODE_SYMBOLS* letterToMorseCode(char c, unsigned short *count);

//  Converts a word to morse code
//  word        - Word to be converted to morse code. Must only
//              include alphabetical characters
//
//  Returns a pointer to an array of morse code symbols representing
//  the supplied word. If word cannot be converted, then the morse
//  code symbols for the word "ERROR" will be returned instead
//
//  This return value must be freed manually
enum MORSE_CODE_SYMBOLS* wordToMorseCode(char* word) {

    //  Declare a pointer to the symbols that will
    //  be returned to the caller
    enum MORSE_CODE_SYMBOLS* symbols;

    //  According to international morse code, a single letter
    //  can have at most four symbols. In order to keep things
    //  simple, enough memory will be allocated to account
    //  for the length of the word if every character required
    //  the maximum amount of symbols. Some of this memory will
    //  go unused, but the benefit of simplicity provides more
    //  benefit here than would attempting to maximizing efficiency
    //
    //  Additionally, each character needs to have a WAIT symbol
    //  at the end to simulate the natural pause between letters.
    //  Finally, the last symbol must be the END symbol to signal
    //  the end of the message
    //
    //  Therefore, the total amount of memory required is:
    //  (word_length * maximum possible symbols for a letter) + (word_length) + 1
    size_t wordLength = strlen(word);
    symbols = malloc((wordLength + (wordLength * MAX_SYMBOLS) + 1) * sizeof(enum MORSE_CODE_SYMBOLS));
    int symbolsPos = 0;

    //  This will be used to determine how many morse code symbols are needed
    //  to represent a character
    unsigned short morseCodeSymbolCount = 0;

    //  Iterate through the word being converted to morse code symbols
    int i;
    for (i = 0; i < wordLength; i++) {

        //  Get each character of the string
        char c = word[i];

        //  If character is a letter, process it
        if (isalpha(c)) {

            //  Convert the character to uppercase
            c = toupper(c);

            //  Get the morse code symbols for the character
            enum MORSE_CODE_SYMBOLS* charSymbols = letterToMorseCode(c, &morseCodeSymbolCount);

            //  Iterate through the symbols returned for the character c.
            //  Add each symbol to the symbols array and increment the symbolPos
            //  to the next available element
            int j;
            for (j = 0; j < morseCodeSymbolCount; j++) {
                symbols[symbolsPos] = charSymbols[j];
                symbolsPos++;
            }

            //  At the end of each character, add the WAIT symbol and increment
            //  the position
            symbols[symbolsPos] = WAIT;
            symbolsPos++;
        }

        //  If a non-letter was found, string cannot be converted to morse code.
        //  Free any allocated memory, then return the morse code symbols for
        //  the word "ERROR" instead
        else {
            free(symbols);
            return wordToMorseCode("ERROR");
        }
    }

    //  If here, there were no errors in converting the word to morse code.
    //  Add the END symbol to the end to indicate the end of the word
    if (i == wordLength) {
        symbols[symbolsPos] = END;
    }

    return symbols;
}

//  Turns on the light indicating a dot in morse code
void showDot() {
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
}

//  Turns off the light indicating a dot in morse code
void hideDot() {
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
}

//  Turns on the light indicating a dash in morse code
void showDash() {
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
}

//  Turns off the light indicating a dash in morse code
void hideDash() {
   GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
}

void timerCallback(Timer_Handle myHandle, int_fast16_t status) {

    //  State transition logic
    switch (state) {

        //  Initial state of the state machine
        case MESSAGE_INIT:

            //  If the assigned amount of periods have passed
            //  while in this state, transition to a new state
            //  based on the next symbol to be flashed by the
            //  state machine. The periodCount must also be
            //  reset here so the next state can successfully
            //  start with a value of 0 periods having passed
            if (periodCount == INIT_PERIODS) {
                if (nextSymbol == DOT) {
                    state = MESSAGE_FLASH_DOT;
                    periodCount = 0;

                }
                else if (nextSymbol == DASH) {
                    state = MESSAGE_FLASH_DASH;
                    periodCount = 0;
                }
            }

            break;

        //  State indicating that the state machine is flashing a dot
        case MESSAGE_FLASH_DOT:

            //  If the assigned amount of periods have passed while in
            //  this state, then the dot symbol has been flashed and the
            //  state machine will transition into a pause state. The
            //  periodCount will also be reset
            if (periodCount == FLASH_DOT_PERIODS) {
                state = MESSAGE_PAUSE_SYMBOL;
                periodCount = 0;
            }

            break;

        //  State indicating that the state machine is flashing a dash
        case MESSAGE_FLASH_DASH:

            //  If the assigned amount of periods have passed while in
            //  this state, then the dash symbol has been flashed and the
            //  state machine will transition into a pause state. The
            //  periodCount will also be reset
            if (periodCount == FLASH_DASH_PERIODS) {
                state = MESSAGE_PAUSE_SYMBOL;
                periodCount = 0;
            }

            break;

        //  State indicating that a symbol has just been flashed and the
        //  state machine is disabling all LEDs and pausing
        case MESSAGE_PAUSE_SYMBOL:

            //  If the assigned amount of periods have passed while in
            //  this state, then the state machine must determine which
            //  symbol will be flashed next and transition into the appropriate
            //  state. If the nextSymbol is either DOT or DASH,
            //  the state machine will ultimately flash another symbol.
            //  If the nextSymbol is WAIT, then a letter has fully been
            //  flashed and the state machine must transition into another
            //  pause-related state. If nextSymbol is END, then the entire
            //  word has been flashed, and the state machine must transition
            //  into yet another pause-related state. periodCount must
            //  also be reset
            if (periodCount == MESSAGE_PAUSE_SYMBOL_PERIODS) {

                if (nextSymbol == DOT) {
                    state = MESSAGE_FLASH_DOT;
                    periodCount = 0;
                }
                else if (nextSymbol == DASH) {
                    state = MESSAGE_FLASH_DASH;
                    periodCount = 0;
                }
                else if (nextSymbol == WAIT) {
                    state = MESSAGE_PAUSE_CHAR;
                    periodCount = 0;
                }
                else if (nextSymbol == END) {
                    state = MESSAGE_PAUSE_WORD;
                    periodCount = 0;
                }

            }

            break;

        //  State indicating that a letter has just been flashed and the
        //  state machine is pausing
        case MESSAGE_PAUSE_CHAR:

            //  If the assigned amount of periods have passed while in
            //  this state, then the state machine must transition
            //  into a new state based on the nextSymbol to be flashed.
            //  If the nextSymbol is END, then the entire word has been
            //  flashed and the system will transition into another
            //  pause-related state. periodCount will be reset
            if (periodCount == MESSAGE_PAUSE_CHAR_PERIODS) {

                if (nextSymbol == DOT) {
                    state = MESSAGE_FLASH_DOT;
                    periodCount = 0;

                }
                else if (nextSymbol == DASH) {
                    state = MESSAGE_FLASH_DASH;
                    periodCount = 0;
                }

                else if (nextSymbol == END) {
                    state = MESSAGE_PAUSE_WORD;
                    periodCount = 0;
                }

            }

            break;

        //  State indicating that a word has just been flashed and the system
        //  is determining what word to flash next
        case MESSAGE_PAUSE_WORD:

            //  If the assigned amount of periods have passed while in
            //  this state, then the state machine must transition
            //  into a new state based on the nextSymbol to be flashed,
            //  which will be dependent on the new word to flash. periodCount
            //  will be reset
            if (periodCount == MESSAGE_PAUSE_WORD_PERIODS) {
                if (nextSymbol == DOT) {
                    state = MESSAGE_FLASH_DOT;
                    periodCount = 0;
                }
                else if (nextSymbol == DASH) {
                    state = MESSAGE_FLASH_DASH;
                    periodCount = 0;
                }
            }

            break;

        //  If something unexpected happened, transition into the initialization state
        default:
            state = MESSAGE_INIT;
    }

    //  State action logic
    switch (state) {
        case MESSAGE_INIT:

            //  Turn off the dot and dash lights if they happen to be on
            hideDot();
            hideDash();

            //  By default, the word to be flashed will be SOS. Determine
            //  what sequence of morse code symbols are necessary to flash
            //  this word, then get the nextSymbol in the sequence to be
            //  flashed
            word = "SOS";
            sequence = wordToMorseCode(word);
            sequencePos = 0;
            nextSymbol = sequence[sequencePos];

            periodCount++;

            break;

        case MESSAGE_FLASH_DOT:

            //  If it's the first tick in this state, flash a dot
            if (periodCount == 0) {
                showDot();
            }

            periodCount++;

            break;

        case MESSAGE_FLASH_DASH:

            //  If it's the first tick in the state, flash a dash
            if (periodCount == 0) {
                showDash();
            }

            periodCount++;

            break;

        case MESSAGE_PAUSE_SYMBOL:

            //  Turn off the dot and dash lights
            hideDot();
            hideDash();

            //  If state machine is about to transition out of this
            //  state, update the sequencePos and determine the
            //  nextSymbol to be flashed
            if (periodCount == MESSAGE_PAUSE_SYMBOL_PERIODS - 1) {
                sequencePos++;
                nextSymbol = sequence[sequencePos];
            }

            periodCount++;

            break;

        case MESSAGE_PAUSE_CHAR:

            //  If state machine is about to transition out of this
            //  state, update the sequencePos and determine the
            //  nextSymbol to be flashed
            if (periodCount == MESSAGE_PAUSE_CHAR_PERIODS - 1) {
                sequencePos++;
                nextSymbol = sequence[sequencePos];
            }

            periodCount++;

            break;

        case MESSAGE_PAUSE_WORD:

            //  If state machine is about to transition out of this
            //  state, determine whether or not a button press has
            //  to be sent
            if (periodCount == MESSAGE_PAUSE_WORD_PERIODS - 1) {

                //  If the button was pressed, change the word
                if (buttonPressed == 1) {

                    //  Perform string comparisons to determine
                    //  what word to use next
                    if (strcmp(word, "SOS") == 0) {
                        word = "OK";
                    }
                    else if (strcmp(word, "OK") == 0) {
                        word = "SOS";
                    }

                    //  Reset the sequencePos, determine the new morse code
                    //  symbol sequence, and get the nextSymbol to be flashed
                    sequencePos = 0;
                    sequence = wordToMorseCode(word);
                    nextSymbol = sequence[sequencePos];

                    //  Reset the buttonPressed variable
                    buttonPressed = 0;
                }

                //  Otherwise, just reset sequencePosition and start over with the
                //  same word
                else
                {
                    sequencePos = 0;
                    nextSymbol = sequence[sequencePos];
                }

            }

            periodCount++;

            break;
    }

}

void initTimer(void) {
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        //  Failed to initialized timer
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        //  Failed to start timer
        while (1) {}
    }
}

//  Callback function to be used whenever any button on
//  the device is pressed
void gpioButtonPress(uint_least8_t index) {

    //  Set global variable indicating button has been
    //  pressed
    buttonPressed = 1;
}

//  ============================
//  ======== mainThread ========
//  ============================
void *mainThread(void *arg0)
{
    //  Call driver init functions
    GPIO_init();

    //  Configure the LED and button pins
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING); // SW2

    //  Install Button callback
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonPress);

    //  Enable interrupts
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    //  If more than one input pin is available for your device, interrupts
    //  will be enabled on CONFIG_GPIO_BUTTON1.
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {

        //  Configure BUTTON1 pin
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING); // SW3

        //  Install Button callback
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonPress);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    initTimer();

    //  Free the malloced memory
    free(sequence);

    return (NULL);
}

//  Converts a letter to morse code symbols
//  c       - Letter to be converted, must be 'a' - 'z' or 'A' - 'Z'
//  count   - Value indicating the amount of morse code symboled returns
//
//  Returns a pointer to an array of morse code symbols. If character
//  cannot be converted to morse code, it returns the END morse code
//  symbol, and count will be set to 0
//
//  This return value must be freed manually
enum MORSE_CODE_SYMBOLS* letterToMorseCode(char c, unsigned short *count) {
    enum MORSE_CODE_SYMBOLS* symbols;

    if (c == 'A') {
        symbols = malloc(2 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        *count = 2;
    }
    else if (c == 'B') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DOT;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'C') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DASH;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'D') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DOT;
        *count = 3;
    }
    else if (c == 'E') {
        symbols = malloc(1 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        *count = 1;
    }
    else if (c == 'F') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        symbols[2] = DASH;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'G') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DASH;
        symbols[2] = DOT;
        *count = 3;
    }
    else if (c == 'H') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        symbols[2] = DOT;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'I') {
        symbols = malloc(2 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        *count = 2;
    }
    else if (c == 'J') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        symbols[2] = DASH;
        symbols[3] = DASH;
        *count = 4;
    }
    else if (c == 'K') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DASH;
        *count = 3;
    }
    else if (c == 'L') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        symbols[2] = DOT;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'M') {
        symbols = malloc(2 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DASH;
        *count = 2;
    }
    else if (c == 'N') {
        symbols = malloc(2 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        *count = 2;
    }
    else if (c == 'O') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DASH;
        symbols[2] = DASH;
        *count = 3;
    }
    else if (c == 'P') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        symbols[2] = DASH;
        symbols[3] = DOT;
        *count = 4;
    }
    else if (c == 'Q') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DASH;
        symbols[2] = DOT;
        symbols[3] = DASH;
        *count = 4;
    }
    else if (c == 'R') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        symbols[2] = DOT;
        *count = 3;
    }
    else if (c == 'S') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        symbols[2] = DOT;
        *count = 3;
    }
    else if (c == 'T') {
        symbols = malloc(1 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        *count = 1;
    }
    else if (c == 'U') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        symbols[2] = DASH;
        *count = 3;
    }
    else if (c == 'V') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DOT;
        symbols[2] = DOT;
        symbols[3] = DASH;
        *count = 4;
    }
    else if (c == 'W') {
        symbols = malloc(3 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DOT;
        symbols[1] = DASH;
        symbols[2] = DASH;
        *count = 3;
    }
    else if (c == 'X') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DOT;
        symbols[3] = DASH;
        *count = 4;
    }
    else if (c == 'Y') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DOT;
        symbols[2] = DASH;
        symbols[3] = DASH;
        *count = 4;
    }
    else if (c == 'Z') {
        symbols = malloc(4 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = DASH;
        symbols[1] = DASH;
        symbols[2] = DOT;
        symbols[3] = DOT;
        *count = 4;
    }
    else {
        symbols = malloc(1 * sizeof(enum MORSE_CODE_SYMBOLS));
        symbols[0] = END;
        *count = 0;
    }

    return symbols;
}
